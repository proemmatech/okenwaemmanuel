export interface SocialProfile {
  platform: 'Instagram' | 'TikTok' | 'Facebook';
  handle: string;
  url: string;
  label: string;
}

export interface InitiativeItem {
  id: string;
  index: string;
  title: string;
  kind: string;
  status: string;
  summary: string;
  highlights: string[];
  href?: string;
  linkLabel?: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export const IDENTITY = {
  fullName: 'Okenwa Chibunna Emmanuel',
  preferredName: 'Okenwa Emmanuel',
  roles: [
    'Web Developer',
    'Electrical Engineering Student',
    'Technology Enthusiast',
    'Founder of EmmaTechPro',
  ],
  webFocus: 'Frontend Development and Technical SEO',
  academicDiscipline: 'Electrical Engineering',
  location: 'Obosi, Anambra State, Nigeria',
  portraitPath: '/okenwa-chibunna-emmanuel.jpg',
  portraitAlt:
    'Portrait of Okenwa Chibunna Emmanuel, Web Developer and Founder of EmmaTechPro',
  brand: {
    name: 'EmmaTechPro',
    slogan: 'Build · Innovate · Empower',
    url: 'https://emmatechpro.netlify.app/',
    relationship: 'Founder',
    description:
      'EmmaTechPro is the technology brand founded by Okenwa Chibunna Emmanuel, connecting his web development practice, digital solutions work, technical learning, and long-term digital ambitions.',
  },
  contact: {
    preferenceNote: 'WhatsApp is preferred for faster response.',
    whatsappDisplay: '07077635760',
    whatsappInternational: '+234 707 763 5760',
    whatsappUrl: 'https://wa.me/2347077635760',
    email: 'proemmatech@gmail.com',
    emailHref: 'mailto:proemmatech@gmail.com',
    phoneDisplay: '0701 457 9620',
    phoneHref: 'tel:+2347014579620',
  },
  socialProfiles: [
    {
      platform: 'Instagram',
      handle: '@emma_obosi',
      url: 'https://www.instagram.com/emma_obosi/',
      label: 'Instagram (@emma_obosi)',
    },
    {
      platform: 'TikTok',
      handle: '@emmatechpro1',
      url: 'https://www.tiktok.com/@emmatechpro1',
      label: 'TikTok (@emmatechpro1)',
    },
    {
      platform: 'Facebook',
      handle: 'Okenwa Chibunna Emmanuel',
      url: 'https://www.facebook.com/profile.php?id=61577152057402',
      label: 'Facebook Profile',
    },
  ] as SocialProfile[],
  activePractice: [
    {
      name: 'HTML5 & Semantic Structure',
      detail: 'Clean document outlines, meaningful landmarks, and crawlable content hierarchy.',
    },
    {
      name: 'CSS & Responsive Web Design',
      detail: 'Fluid layouts across desktop and mobile viewports with disciplined spacing and contrast.',
    },
    {
      name: 'JavaScript & TypeScript',
      detail: 'Interactive frontend logic with predictable typing and modular component structure.',
    },
    {
      name: 'React & Vite',
      detail: 'Component-driven web interfaces built for fast bundling and maintainable architecture.',
    },
    {
      name: 'Technical SEO & Schema.org',
      detail: 'Metadata hygiene, canonical strategy, indexability, and truthful JSON-LD structured data.',
    },
    {
      name: 'Accessibility Fundamentals',
      detail: 'Keyboard navigation, focus states, descriptive labels, and legible typographic contrast.',
    },
    {
      name: 'Frontend Architecture',
      detail: 'Organizing data, UI components, and styles cleanly for long-term clarity.',
    },
    {
      name: 'Electrical Engineering Foundations',
      detail: 'Ongoing academic training in circuits, systems thinking, and analytical problem-solving.',
    },
  ],
  exploringAreas: [
    {
      name: 'Embedded Systems',
      detail: 'Studying how microcontrollers and low-level hardware logic interact with physical circuits.',
    },
    {
      name: 'Hardware–Web Integration',
      detail: 'Exploring practical bridges between electrical engineering concepts and browser interfaces.',
    },
    {
      name: 'Full-Stack Development',
      detail: 'Expanding beyond frontend architecture into backend services, APIs, and data persistence.',
    },
    {
      name: 'AI Search & Digital Identity Discoverability',
      detail: 'Learning how search engines and AI systems parse factual entities, relationships, and semantic markup.',
    },
    {
      name: 'Editorial UI & Interaction Design',
      detail: 'Refining typographic hierarchy, whitespace, and restrained motion that serves clarity.',
    },
  ],
  initiatives: [
    {
      id: 'emmatechpro',
      index: '01',
      title: 'EmmaTechPro',
      kind: 'Founded Technology Brand',
      status: 'Active Initiative',
      summary:
        'A web and technology brand founded by Okenwa Chibunna Emmanuel under the guiding principle "Build · Innovate · Empower." EmmaTechPro serves as the dedicated home for practical web development work and digital initiatives.',
      highlights: [
        'Official standalone brand website at emmatechpro.netlify.app',
        'Focused on practical web solutions, custom coding, and digital consulting',
        'Connected to Okenwa Emmanuel’s ongoing technical work while keeping personal identity distinct',
      ],
      href: 'https://emmatechpro.netlify.app/',
      linkLabel: 'Visit EmmaTechPro',
    },
    {
      id: 'digital-identity',
      index: '02',
      title: 'Personal Digital Identity & Technical SEO Architecture',
      kind: 'Frontend & Search Discoverability',
      status: 'Live Foundation',
      summary:
        'This website itself is built as a structured digital identity platform designed for human clarity, search engine indexability, and factual entity consistency across Google Search, Bing, and AI discovery systems.',
      highlights: [
        'Semantic HTML5 document outline and accessible navigation',
        'Consistent Schema.org Person, Organization, WebSite, ProfilePage, and FAQPage JSON-LD',
        'Responsive React, TypeScript, and Vite frontend with zero inflated claims',
      ],
    },
    {
      id: 'engineering-web-study',
      index: '03',
      title: 'Electrical Engineering & Systems Learning Track',
      kind: 'Academic & Technical Exploration',
      status: 'Ongoing Study',
      summary:
        'Continuous coursework and independent study bridging Electrical Engineering fundamentals with software craftsmanship—exploring how structured engineering reasoning informs cleaner web architecture and future hardware–web interfaces.',
      highlights: [
        'Grounded in Electrical Engineering academic discipline',
        'Active exploration in embedded systems and hardware–web integration',
        'Documenting skills honestly without overstating early-stage exploration',
      ],
    },
  ] as InitiativeItem[],
  faqs: [
    {
      id: 'who-is',
      question: 'Who is Okenwa Chibunna Emmanuel?',
      answer:
        'Okenwa Chibunna Emmanuel, also known as Okenwa Emmanuel, is a Web Developer, Electrical Engineering student, technology enthusiast, and the Founder of EmmaTechPro, based in Obosi, Anambra State, Nigeria.',
    },
    {
      id: 'technical-focus',
      question: 'What does Okenwa Chibunna Emmanuel focus on technically?',
      answer:
        'His primary web focus is Frontend Development and Technical SEO, working with HTML5, CSS, JavaScript, TypeScript, React, Vite, responsive web design, semantic HTML, accessibility, and Schema.org structured data alongside his academic study of Electrical Engineering.',
    },
    {
      id: 'emmatechpro-relationship',
      question:
        "What is EmmaTechPro and what is Okenwa Chibunna Emmanuel's relationship to it?",
      answer:
        'EmmaTechPro (Build · Innovate · Empower) is the technology brand founded by Okenwa Chibunna Emmanuel, accessible at https://emmatechpro.netlify.app/. It reflects his ongoing web development work, technical projects, and long-term digital initiatives.',
    },
    {
      id: 'exploring-areas',
      question: 'What areas is Okenwa Chibunna Emmanuel currently exploring?',
      answer:
        'Alongside active frontend and SEO practice, he is exploring embedded systems, hardware–web integration, full-stack development, AI search and digital identity discoverability, and editorial UI and interaction design.',
    },
    {
      id: 'how-to-contact',
      question: 'How can you contact Okenwa Chibunna Emmanuel?',
      answer:
        'WhatsApp is preferred for faster response at +234 707 763 5760 (https://wa.me/2347077635760). He can also be reached by email at proemmatech@gmail.com or by telephone at 0701 457 9620.',
    },
    {
      id: 'official-profiles',
      question: "What are Okenwa Chibunna Emmanuel's official online profiles?",
      answer:
        'His verified public profiles are EmmaTechPro (https://emmatechpro.netlify.app/), Instagram (@emma_obosi), TikTok (@emmatechpro1), and Facebook.',
    },
  ] as FaqItem[],
};
