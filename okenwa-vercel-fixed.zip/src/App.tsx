/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useEffect } from 'react';
import { MotionConfig } from 'motion/react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { PracticeSection } from './components/PracticeSection';
import { InitiativesSection } from './components/InitiativesSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export default function App() {
  // Dynamically keep canonical & og:url synced to the live deployed origin without hardcoding an unconfirmed domain
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const currentUrl = `${window.location.origin}${window.location.pathname}`;

    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = currentUrl;

    let ogUrl = document.querySelector<HTMLMetaElement>('meta[property="og:url"]');
    if (!ogUrl) {
      ogUrl = document.createElement('meta');
      ogUrl.setAttribute('property', 'og:url');
      document.head.appendChild(ogUrl);
    }
    ogUrl.content = currentUrl;
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-white text-zinc-900">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-lg focus:bg-zinc-950 focus:px-4 focus:py-2 focus:text-xs focus:font-medium focus:text-white"
        >
          Skip to main content
        </a>
        <Header />
        <main id="main-content">
          <Hero />
          <AboutSection />
          <PracticeSection />
          <InitiativesSection />
          <FaqSection />
          <ContactSection />
        </main>
        <Footer />
      </div>
    </MotionConfig>
  );
}
