import { IDENTITY } from '../data/identity';

const IDENTITY_LEDGER = [
  { label: 'Full Name', value: IDENTITY.fullName },
  { label: 'Preferred Short Identity', value: IDENTITY.preferredName },
  { label: 'Web Focus', value: IDENTITY.webFocus },
  { label: 'Academic Discipline', value: IDENTITY.academicDiscipline },
  { label: 'Brand Relationship', value: `Founder of ${IDENTITY.brand.name}` },
  { label: 'Public Location', value: IDENTITY.location },
];

export function AboutSection() {
  return (
    <section
      id="about"
      aria-labelledby="about-heading"
      className="border-t border-zinc-200 bg-[#FAFAFA] py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-14">
          {/* Left Narrative Column */}
          <div className="lg:col-span-7">
            <p className="font-mono text-xs font-medium text-zinc-500 tabular-nums">
              01 · About &amp; Personal Journey
            </p>
            <h2
              id="about-heading"
              className="mt-3 font-display text-3xl font-semibold tracking-tight text-zinc-950 [text-wrap:balance] sm:text-4xl"
            >
              Connecting Electrical Engineering discipline with structured web craft.
            </h2>

            <div className="mt-6 space-y-5 text-base leading-relaxed text-zinc-700">
              <p>
                I am <strong className="font-semibold text-zinc-950">{IDENTITY.fullName}</strong>{' '}
                (also known professionally as{' '}
                <strong className="font-semibold text-zinc-950">{IDENTITY.preferredName}</strong>),
                an Electrical Engineering student and frontend web developer based in{' '}
                {IDENTITY.location}.
              </p>
              <p>
                My academic work in Electrical Engineering shapes how I approach software:
                paying attention to underlying structure, clean signal flow, reliability,
                and how individual components work together as a coherent system. In web
                development, that mindset translates into semantic HTML, accessible layouts,
                maintainable TypeScript and React code, and strong technical SEO
                foundations.
              </p>
              <p>
                Through <strong className="font-semibold text-zinc-950">{IDENTITY.brand.name}</strong>,
                the technology brand I founded, I apply what I build and continue to learn in
                practical web projects while steadily exploring embedded systems,
                hardware–web integration, full-stack engineering, and how search engines and
                AI platforms understand real digital identities.
              </p>
            </div>
          </div>

          {/* Right Structured Identity Ledger */}
          <div className="lg:col-span-5">
            <div className="rounded-xl border border-zinc-200 bg-white p-6 sm:p-7">
              <div className="flex items-center justify-between border-b border-zinc-200 pb-4">
                <h3 className="font-display text-base font-semibold text-zinc-950">
                  Verified Identity Summary
                </h3>
                <span
                  aria-hidden="true"
                  className="h-2 w-6 rounded-full bg-[#F5D042]"
                />
              </div>

              <dl className="divide-y divide-zinc-100">
                {IDENTITY_LEDGER.map((entry) => (
                  <div key={entry.label} className="py-3.5">
                    <dt className="text-xs font-medium text-zinc-500">{entry.label}</dt>
                    <dd className="mt-1 text-sm font-medium text-zinc-900">
                      {entry.value}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
