import { useState } from 'react';
import { ArrowUpRight, Mail, Phone, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { IDENTITY } from '../data/identity';

export function Hero() {
  const [imageError, setImageError] = useState(false);

  return (
    <section
      id="top"
      aria-labelledby="hero-heading"
      className="relative overflow-hidden bg-white pt-6 pb-16 sm:pt-10 sm:pb-24 lg:pt-12 lg:pb-28"
    >
      {/* Subtle architectural hairline backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 mx-auto h-full max-w-6xl border-x border-zinc-100/80"
      />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12 lg:gap-8">
          {/* Portrait Composition — Placed first on mobile for art-directed framing, right on desktop */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="order-1 lg:order-2 lg:col-span-6 lg:col-start-7"
          >
            <div className="relative mx-auto max-w-[340px] sm:max-w-[390px] lg:max-w-[440px] lg:ml-auto lg:mr-0">
              <div className="relative flex justify-center lg:justify-end">
                {!imageError ? (
                  <div className="relative w-full aspect-[2/3] overflow-hidden bg-white">
                    <img
                      src={IDENTITY.portraitPath}
                      alt={IDENTITY.portraitAlt}
                      onError={() => setImageError(true)}
                      loading="eager"
                      decoding="async"
                      className="portrait-mask relative z-10 h-full w-full object-contain object-bottom mix-blend-multiply"
                    />
                    {/* Soft lower & edge dissolves into white canvas */}
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-x-0 bottom-0 z-20 h-32 bg-gradient-to-t from-white via-white/75 to-transparent sm:h-36"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-y-0 left-0 z-20 w-8 bg-gradient-to-r from-white to-transparent"
                    />
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-y-0 right-0 z-20 w-8 bg-gradient-to-l from-white to-transparent"
                    />
                  </div>
                ) : (
                  /* Graceful editorial fallback */
                  <div className="relative flex aspect-[2/3] w-full flex-col items-center justify-center overflow-hidden">
                    <div
                      aria-hidden="true"
                      className="portrait-mask flex h-full w-full flex-col items-center justify-center bg-gradient-to-b from-zinc-100 via-zinc-50 to-white px-6 text-center"
                    >
                      <svg
                        viewBox="0 0 240 280"
                        className="h-56 w-48 text-zinc-300"
                        fill="none"
                        aria-hidden="true"
                      >
                        <circle cx="120" cy="88" r="42" fill="currentColor" opacity="0.55" />
                        <path
                          d="M44 246c0-42 34-76 76-76s76 34 76 76"
                          fill="currentColor"
                          opacity="0.45"
                        />
                      </svg>
                      <p className="mt-2 font-display text-sm font-medium tracking-tight text-zinc-500">
                        {IDENTITY.fullName}
                      </p>
                      <p className="mt-0.5 text-xs text-zinc-400">
                        {IDENTITY.location}
                      </p>
                    </div>
                  </div>
                )}

                {/* Selective Glassmorphism Detail: Translucent identity note anchored at the lower fade */}
                <div className="absolute bottom-2 left-2 right-2 z-30 mx-auto max-w-sm rounded-xl border border-zinc-200/80 bg-white/75 px-4 py-3 backdrop-blur-md shadow-[0_8px_30px_rgba(0,0,0,0.04)] sm:bottom-4 sm:left-auto sm:right-2">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-xs font-medium text-zinc-900">
                        {IDENTITY.webFocus}
                      </p>
                      <p className="mt-0.5 text-xs text-zinc-500">
                        {IDENTITY.academicDiscipline} · {IDENTITY.brand.name}
                      </p>
                    </div>
                    <span
                      aria-hidden="true"
                      className="h-2.5 w-2.5 shrink-0 rounded-sm bg-[#F5D042]"
                    />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Editorial Typography Column */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
            className="order-2 lg:order-1 lg:col-span-6 lg:pr-6"
          >
            {/* Unboxed location & role metadata line (Zero-pill discipline) */}
            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs font-medium text-zinc-500">
              <span className="inline-flex items-center gap-1.5 text-zinc-700">
                <MapPin className="h-3.5 w-3.5 text-zinc-500" aria-hidden="true" />
                {IDENTITY.location}
              </span>
              <span aria-hidden="true" className="text-zinc-300">
                ·
              </span>
              <span>Preferred short name: {IDENTITY.preferredName}</span>
            </div>

            {/* Subtle soft yellow accent rule */}
            <div aria-hidden="true" className="mt-5 h-[3px] w-12 bg-[#F5D042]" />

            <h1
              id="hero-heading"
              className="mt-5 font-display text-4xl font-semibold tracking-tight text-zinc-950 [text-wrap:balance] sm:text-5xl lg:text-[3.75rem] lg:leading-[1.06]"
            >
              {IDENTITY.fullName}
            </h1>

            {/* Verified Identity Roles — Clean Typographic Separators */}
            <p className="mt-4 text-base font-medium leading-relaxed text-zinc-800 sm:text-lg">
              Web Developer <span className="mx-1.5 text-zinc-300">·</span> Electrical
              Engineering Student <span className="mx-1.5 text-zinc-300">·</span>{' '}
              Technology Enthusiast <span className="mx-1.5 text-zinc-300">·</span>{' '}
              Founder of{' '}
              <a
                href={IDENTITY.brand.url}
                target="_blank"
                rel="noopener noreferrer"
                className="underline decoration-[#F5D042] decoration-2 underline-offset-4 transition-colors hover:text-zinc-950"
              >
                {IDENTITY.brand.name}
              </a>
            </p>

            <p className="mt-5 max-w-xl text-base leading-relaxed text-zinc-600">
              Building clean, structured frontend web experiences and technical SEO
              foundations alongside ongoing academic study in Electrical Engineering.
              Founder of{' '}
              <span className="font-medium text-zinc-900">{IDENTITY.brand.name}</span>{' '}
              ({IDENTITY.brand.slogan}).
            </p>

            {/* Primary WhatsApp Action + Direct Alternative Links */}
            <div className="mt-8 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:gap-6">
              <a
                href={IDENTITY.contact.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-zinc-950 px-6 py-3 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-all duration-150 hover:bg-zinc-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-950"
              >
                <span>Message on WhatsApp</span>
                <ArrowUpRight className="h-4 w-4 text-[#FDE047]" aria-hidden="true" />
              </a>

              <div className="flex flex-wrap items-center gap-4 text-sm text-zinc-600">
                <a
                  href={IDENTITY.contact.emailHref}
                  className="inline-flex min-h-[48px] items-center gap-1.5 whitespace-nowrap transition-colors hover:text-zinc-950 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
                >
                  <Mail className="h-4 w-4 text-zinc-400" aria-hidden="true" />
                  <span>{IDENTITY.contact.email}</span>
                </a>
                <a
                  href={IDENTITY.contact.phoneHref}
                  className="inline-flex min-h-[48px] items-center gap-1.5 whitespace-nowrap tabular-nums transition-colors hover:text-zinc-950 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
                >
                  <Phone className="h-4 w-4 text-zinc-400" aria-hidden="true" />
                  <span>{IDENTITY.contact.phoneDisplay}</span>
                </a>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Quiet Horizontal Identity Strip Below Split */}
        <div className="mt-12 grid grid-cols-1 gap-4 border-t border-zinc-200 pt-6 sm:grid-cols-3 sm:gap-8">
          <div>
            <p className="text-xs font-medium text-zinc-500">Web Focus</p>
            <p className="mt-1 text-sm font-medium text-zinc-900">{IDENTITY.webFocus}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-zinc-500">Academic Discipline</p>
            <p className="mt-1 text-sm font-medium text-zinc-900">
              {IDENTITY.academicDiscipline}
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-zinc-500">Founded Initiative</p>
            <p className="mt-1 text-sm font-medium text-zinc-900">
              {IDENTITY.brand.name} — {IDENTITY.brand.slogan}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
