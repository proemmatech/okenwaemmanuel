import { ArrowUpRight } from 'lucide-react';
import { IDENTITY } from '../data/identity';

export function InitiativesSection() {
  return (
    <section
      id="emmatechpro"
      aria-labelledby="initiatives-heading"
      className="border-t border-zinc-200 bg-[#FAFAFA] py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <p className="font-mono text-xs font-medium text-zinc-500 tabular-nums">
            03 · EmmaTechPro &amp; Real Work
          </p>
          <h2
            id="initiatives-heading"
            className="mt-3 font-display text-3xl font-semibold tracking-tight text-zinc-950 [text-wrap:balance] sm:text-4xl"
          >
            {IDENTITY.brand.name} and selected personal initiatives.
          </h2>
          <p className="mt-3 text-base leading-relaxed text-zinc-600">
            Rather than padding a portfolio with placeholder case studies, this section
            documents the real brand I founded and the genuine digital and academic
            foundations I am building.
          </p>
        </div>

        {/* Dedicated EmmaTechPro Brand Relationship Panel */}
        <div className="mt-10 rounded-xl border border-zinc-200 bg-white p-6 sm:p-10">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-8">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-medium text-zinc-500">
                <span className="text-zinc-900">Founded Brand</span>
                <span aria-hidden="true">·</span>
                <span>{IDENTITY.brand.slogan}</span>
                <span aria-hidden="true">·</span>
                <span>Official Website</span>
              </div>

              <h3 className="mt-3 font-display text-2xl font-semibold tracking-tight text-zinc-950 sm:text-3xl">
                {IDENTITY.brand.name}
              </h3>

              <p className="mt-4 max-w-2xl text-base leading-relaxed text-zinc-700">
                I am the founder of{' '}
                <strong className="font-semibold text-zinc-950">
                  {IDENTITY.brand.name}
                </strong>
                , a technology brand guided by the slogan{' '}
                <strong className="font-semibold text-zinc-950">
                  {IDENTITY.brand.slogan}
                </strong>
                . {IDENTITY.brand.name} connects my web development practice, digital
                solutions work, technical learning, and long-term digital ambitions. It
                maintains its own standalone website while remaining closely tied to my
                identity as its founder.
              </p>
            </div>

            <div className="flex flex-col items-start gap-3 lg:col-span-4 lg:items-end">
              <a
                href={IDENTITY.brand.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-zinc-950 px-6 py-3 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-colors hover:bg-zinc-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-950"
              >
                <span>Visit emmatechpro.netlify.app</span>
                <ArrowUpRight className="h-4 w-4 text-[#FDE047]" aria-hidden="true" />
              </a>
              <p className="text-xs text-zinc-500 lg:text-right">
                Official standalone {IDENTITY.brand.name} website
              </p>
            </div>
          </div>
        </div>

        {/* Genuine Initiatives List */}
        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {IDENTITY.initiatives.map((item) => (
            <article
              key={item.id}
              className="flex flex-col justify-between rounded-xl border border-zinc-200 bg-white p-6"
            >
              <div>
                <div className="flex items-center justify-between gap-2 text-xs text-zinc-500">
                  <span className="font-mono tabular-nums">{item.index}</span>
                  <span>
                    {item.kind} · {item.status}
                  </span>
                </div>

                <h3 className="mt-4 font-display text-lg font-semibold text-zinc-950">
                  {item.title}
                </h3>

                <p className="mt-3 text-sm leading-relaxed text-zinc-600">
                  {item.summary}
                </p>

                <ul className="mt-5 space-y-2 border-t border-zinc-100 pt-4 text-xs leading-relaxed text-zinc-600">
                  {item.highlights.map((highlight) => (
                    <li key={highlight} className="flex items-start gap-2">
                      <span
                        aria-hidden="true"
                        className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#EAB308]"
                      />
                      <span>{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {item.href && item.linkLabel && (
                <div className="mt-6 pt-2">
                  <a
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[44px] items-center gap-1.5 text-sm font-medium text-zinc-950 underline decoration-[#F5D042] decoration-2 underline-offset-4 transition-colors hover:text-zinc-700"
                  >
                    <span>{item.linkLabel}</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                </div>
              )}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
