import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { IDENTITY } from '../data/identity';

export function FaqSection() {
  const [openIds, setOpenIds] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    IDENTITY.faqs.forEach((f, idx) => {
      initial[f.id] = idx < 2;
    });
    return initial;
  });

  const allExpanded = IDENTITY.faqs.every((f) => openIds[f.id]);

  const toggleItem = (id: string) => {
    setOpenIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleAll = () => {
    const nextState = !allExpanded;
    const updated: Record<string, boolean> = {};
    IDENTITY.faqs.forEach((f) => {
      updated[f.id] = nextState;
    });
    setOpenIds(updated);
  };

  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className="border-t border-zinc-200 bg-white py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="flex flex-col justify-between gap-4 border-b border-zinc-200 pb-8 sm:flex-row sm:items-end">
          <div className="max-w-2xl">
            <p className="font-mono text-xs font-medium text-zinc-500 tabular-nums">
              04 · Factual Identity Q&amp;A
            </p>
            <h2
              id="faq-heading"
              className="mt-3 font-display text-3xl font-semibold tracking-tight text-zinc-950 [text-wrap:balance] sm:text-4xl"
            >
              Frequently asked questions about {IDENTITY.preferredName}.
            </h2>
            <p className="mt-3 text-base leading-relaxed text-zinc-600">
              Concise, factual answers structured for clarity across visitors, search
              engines, and AI discovery platforms.
            </p>
          </div>

          <button
            type="button"
            onClick={toggleAll}
            className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-zinc-200 bg-white px-4 py-2 text-xs font-medium text-zinc-800 whitespace-nowrap shrink-0 transition-colors hover:bg-zinc-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
          >
            {allExpanded ? 'Collapse all' : 'Expand all'}
          </button>
        </div>

        <div className="mt-4 divide-y divide-zinc-200">
          {IDENTITY.faqs.map((faq, idx) => {
            const isOpen = !!openIds[faq.id];
            return (
              <div key={faq.id} className="py-2">
                <h3>
                  <button
                    type="button"
                    onClick={() => toggleItem(faq.id)}
                    aria-expanded={isOpen}
                    aria-controls={`faq-panel-${faq.id}`}
                    className="flex min-h-[56px] w-full items-center justify-between gap-4 py-3 text-left transition-colors hover:text-zinc-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
                  >
                    <span className="flex items-baseline gap-4">
                      <span className="font-mono text-xs text-zinc-400 tabular-nums">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span className="font-display text-lg font-medium text-zinc-950">
                        {faq.question}
                      </span>
                    </span>
                    <ChevronDown
                      className={`h-5 w-5 shrink-0 text-zinc-500 transition-transform duration-200 ${
                        isOpen ? 'rotate-180 text-zinc-950' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                </h3>
                <div
                  id={`faq-panel-${faq.id}`}
                  hidden={!isOpen}
                  className="pb-5 pl-8 pr-6 sm:pl-9"
                >
                  <p className="max-w-3xl text-base leading-relaxed text-zinc-600">
                    {faq.answer}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
