import { useState } from 'react';
import { ArrowUpRight, Mail, Phone, MapPin, Copy, Check } from 'lucide-react';
import { IDENTITY } from '../data/identity';

export function ContactSection() {
  const [copied, setCopied] = useState(false);

  const handleCopyContact = async () => {
    const summary = [
      IDENTITY.fullName,
      `Email: ${IDENTITY.contact.email}`,
      `Phone: ${IDENTITY.contact.phoneDisplay}`,
      `WhatsApp: ${IDENTITY.contact.whatsappUrl}`,
      `Location: ${IDENTITY.location}`,
      `Brand: ${IDENTITY.brand.name} (${IDENTITY.brand.url})`,
    ].join('\n');

    try {
      await navigator.clipboard.writeText(summary);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="border-t border-zinc-200 bg-[#FAFAFA] py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-12">
          {/* Primary Contact Call-to-Action */}
          <div className="lg:col-span-7">
            <p className="font-mono text-xs font-medium text-zinc-500 tabular-nums">
              05 · Direct Contact &amp; Verified Profiles
            </p>
            <h2
              id="contact-heading"
              className="mt-3 font-display text-3xl font-semibold tracking-tight text-zinc-950 [text-wrap:balance] sm:text-4xl"
            >
              Get in touch with {IDENTITY.preferredName}.
            </h2>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-zinc-600">
              For web development inquiries, collaborations, or questions regarding{' '}
              {IDENTITY.brand.name},{' '}
              <strong className="font-medium text-zinc-900">
                {IDENTITY.contact.preferenceNote}
              </strong>
            </p>

            {/* Primary WhatsApp CTA + Copy Details */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href={IDENTITY.contact.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-zinc-950 px-6 py-3 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-colors hover:bg-zinc-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-950"
              >
                <span>Message on WhatsApp ({IDENTITY.contact.whatsappDisplay})</span>
                <ArrowUpRight className="h-4 w-4 text-[#FDE047]" aria-hidden="true" />
              </a>

              <button
                type="button"
                onClick={handleCopyContact}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg border border-zinc-200 bg-white px-5 py-3 text-sm font-medium text-zinc-800 whitespace-nowrap shrink-0 transition-colors hover:bg-zinc-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4 text-zinc-900" aria-hidden="true" />
                    <span>Contact details copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 text-zinc-500" aria-hidden="true" />
                    <span>Copy contact details</span>
                  </>
                )}
              </button>
            </div>

            {/* Alternative Contact Channels */}
            <div className="mt-10 grid grid-cols-1 gap-4 border-t border-zinc-200 pt-8 sm:grid-cols-3">
              <a
                href={IDENTITY.contact.emailHref}
                className="group flex min-h-[48px] flex-col justify-between rounded-xl border border-zinc-200 bg-white p-4 transition-colors hover:border-zinc-300"
              >
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-500">
                  <Mail className="h-3.5 w-3.5" aria-hidden="true" />
                  Email
                </span>
                <span className="mt-2 truncate text-sm font-medium text-zinc-950 group-hover:underline">
                  {IDENTITY.contact.email}
                </span>
              </a>

              <a
                href={IDENTITY.contact.phoneHref}
                className="group flex min-h-[48px] flex-col justify-between rounded-xl border border-zinc-200 bg-white p-4 transition-colors hover:border-zinc-300"
              >
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-500">
                  <Phone className="h-3.5 w-3.5" aria-hidden="true" />
                  Telephone
                </span>
                <span className="mt-2 text-sm font-medium text-zinc-950 tabular-nums group-hover:underline">
                  {IDENTITY.contact.phoneDisplay}
                </span>
              </a>

              <div className="flex min-h-[48px] flex-col justify-between rounded-xl border border-zinc-200 bg-white p-4">
                <span className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-500">
                  <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                  Public Location
                </span>
                <span className="mt-2 text-sm font-medium text-zinc-950">
                  {IDENTITY.location}
                </span>
              </div>
            </div>
          </div>

          {/* Genuine Social Profiles Panel */}
          <div className="lg:col-span-5">
            <div className="rounded-xl border border-zinc-200 bg-white p-6 sm:p-7">
              <div className="border-b border-zinc-200 pb-4">
                <h3 className="font-display text-base font-semibold text-zinc-950">
                  Official Social Profiles
                </h3>
                <p className="mt-1 text-xs text-zinc-500">
                  Only verified public accounts currently maintained by{' '}
                  {IDENTITY.preferredName}.
                </p>
              </div>

              <ul className="divide-y divide-zinc-100">
                {IDENTITY.socialProfiles.map((profile) => (
                  <li key={profile.platform}>
                    <a
                      href={profile.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex min-h-[56px] items-center justify-between gap-4 py-3 text-left transition-colors hover:text-zinc-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
                    >
                      <div>
                        <p className="text-sm font-semibold text-zinc-950">
                          {profile.platform}
                        </p>
                        <p className="text-xs text-zinc-500">{profile.handle}</p>
                      </div>
                      <ArrowUpRight
                        className="h-4 w-4 shrink-0 text-zinc-400"
                        aria-hidden="true"
                      />
                    </a>
                  </li>
                ))}

                <li>
                  <a
                    href={IDENTITY.brand.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex min-h-[56px] items-center justify-between gap-4 py-3 text-left transition-colors hover:text-zinc-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
                  >
                    <div>
                      <p className="text-sm font-semibold text-zinc-950">
                        {IDENTITY.brand.name}
                      </p>
                      <p className="text-xs text-zinc-500">
                        emmatechpro.netlify.app · {IDENTITY.brand.slogan}
                      </p>
                    </div>
                    <ArrowUpRight
                      className="h-4 w-4 shrink-0 text-zinc-400"
                      aria-hidden="true"
                    />
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
