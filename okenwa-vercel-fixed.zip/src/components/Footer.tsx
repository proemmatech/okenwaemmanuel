import { IDENTITY } from '../data/identity';

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-zinc-200 bg-white py-12">
      <div className="mx-auto flex max-w-6xl flex-col justify-between gap-8 px-5 sm:flex-row sm:items-center sm:px-8">
        <div>
          <p className="font-display text-base font-semibold text-zinc-950">
            {IDENTITY.fullName}
          </p>
          <p className="mt-1 text-xs text-zinc-500">
            {IDENTITY.preferredName} · {IDENTITY.webFocus} · {IDENTITY.location}
          </p>
        </div>

        <nav
          aria-label="Footer verified links"
          className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs font-medium text-zinc-600"
        >
          <a
            href={IDENTITY.contact.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[40px] items-center hover:text-zinc-950"
          >
            WhatsApp
          </a>
          <a
            href={IDENTITY.contact.emailHref}
            className="inline-flex min-h-[40px] items-center hover:text-zinc-950"
          >
            Email
          </a>
          <a
            href={IDENTITY.brand.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[40px] items-center hover:text-zinc-950"
          >
            {IDENTITY.brand.name}
          </a>
          {IDENTITY.socialProfiles.map((profile) => (
            <a
              key={profile.platform}
              href={profile.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[40px] items-center hover:text-zinc-950"
            >
              {profile.platform}
            </a>
          ))}
        </nav>

        <p className="text-xs text-zinc-400 tabular-nums">
          © {year} {IDENTITY.fullName}
        </p>
      </div>
    </footer>
  );
}
