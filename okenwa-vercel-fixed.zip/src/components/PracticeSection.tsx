import { useState } from 'react';
import { IDENTITY } from '../data/identity';

type PracticeFilter = 'all' | 'active' | 'exploring';

export function PracticeSection() {
  const [filter, setFilter] = useState<PracticeFilter>('all');

  const showActive = filter === 'all' || filter === 'active';
  const showExploring = filter === 'all' || filter === 'exploring';

  return (
    <section
      id="practice"
      aria-labelledby="practice-heading"
      className="border-t border-zinc-200 bg-white py-20 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="flex flex-col justify-between gap-6 border-b border-zinc-200 pb-8 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="font-mono text-xs font-medium text-zinc-500 tabular-nums">
              02 · Practice &amp; Technical Exploration
            </p>
            <h2
              id="practice-heading"
              className="mt-3 font-display text-3xl font-semibold tracking-tight text-zinc-950 [text-wrap:balance] sm:text-4xl"
            >
              Active web practice and ongoing areas of study.
            </h2>
            <p className="mt-3 text-base leading-relaxed text-zinc-600">
              A clear distinction between technologies I actively work with in frontend
              and technical SEO projects, and broader engineering topics I am currently
              studying and exploring.
            </p>
          </div>

          {/* Interactive Segmented Filter Control */}
          <div
            role="group"
            aria-label="Filter capabilities by stage"
            className="inline-flex w-full items-center gap-1 rounded-lg border border-zinc-200 bg-zinc-100/80 p-1 sm:w-auto"
          >
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'active', label: 'Active Practice' },
                { id: 'exploring', label: 'Exploring' },
              ] as const
            ).map((tab) => {
              const isSelected = filter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilter(tab.id)}
                  aria-pressed={isSelected}
                  className={`min-h-[44px] flex-1 rounded-md px-3.5 py-2 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 sm:flex-initial focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900 ${
                    isSelected
                      ? 'bg-white text-zinc-950 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-950'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-12 space-y-14">
          {showActive && (
            <div>
              <div className="mb-6 flex items-baseline justify-between gap-4">
                <div>
                  <h3 className="font-display text-xl font-semibold text-zinc-950">
                    Active Practice &amp; Foundational Skills
                  </h3>
                  <p className="mt-1 text-sm text-zinc-600">
                    Core technologies and engineering principles applied in current web
                    builds.
                  </p>
                </div>
                <span className="font-mono text-xs text-zinc-500 tabular-nums whitespace-nowrap">
                  {String(IDENTITY.activePractice.length).padStart(2, '0')} areas
                </span>
              </div>

              <div className="grid grid-cols-1 gap-px overflow-hidden rounded-xl border border-zinc-200 bg-zinc-200 sm:grid-cols-2 lg:grid-cols-4">
                {IDENTITY.activePractice.map((item, idx) => (
                  <article
                    key={item.name}
                    className="flex flex-col justify-between bg-white p-6 transition-colors duration-150 hover:bg-[#FAFAFA]"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs text-zinc-400 tabular-nums">
                          {String(idx + 1).padStart(2, '0')}
                        </span>
                        <span
                          aria-hidden="true"
                          className="h-1.5 w-1.5 rounded-full bg-zinc-900"
                        />
                      </div>
                      <h4 className="mt-4 font-display text-base font-semibold text-zinc-950">
                        {item.name}
                      </h4>
                      <p className="mt-2 text-sm leading-relaxed text-zinc-600">
                        {item.detail}
                      </p>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          )}

          {showExploring && (
            <div>
              <div className="mb-6 flex items-baseline justify-between gap-4">
                <div>
                  <h3 className="font-display text-xl font-semibold text-zinc-950">
                    Areas of Exploration &amp; Ongoing Learning
                  </h3>
                  <p className="mt-1 text-sm text-zinc-600">
                    Fields I am actively studying and experimenting with—presented
                    honestly as developing interests.
                  </p>
                </div>
                <span className="font-mono text-xs text-zinc-500 tabular-nums whitespace-nowrap">
                  {String(IDENTITY.exploringAreas.length).padStart(2, '0')} tracks
                </span>
              </div>

              <div className="divide-y divide-zinc-200 rounded-xl border border-zinc-200 bg-[#FAFAFA]">
                {IDENTITY.exploringAreas.map((item, idx) => (
                  <div
                    key={item.name}
                    className="grid grid-cols-1 gap-2 p-5 sm:grid-cols-12 sm:items-center sm:gap-6 sm:px-6"
                  >
                    <div className="flex items-center gap-3 sm:col-span-5">
                      <span className="font-mono text-xs text-zinc-400 tabular-nums">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span
                        aria-hidden="true"
                        className="h-2 w-2 shrink-0 rounded-sm bg-[#F5D042]"
                      />
                      <h4 className="font-display text-base font-semibold text-zinc-950">
                        {item.name}
                      </h4>
                    </div>
                    <p className="text-sm leading-relaxed text-zinc-600 sm:col-span-5">
                      {item.detail}
                    </p>
                    <div className="sm:col-span-2 sm:text-right">
                      <span className="text-xs font-medium text-zinc-500">
                        Ongoing study
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
